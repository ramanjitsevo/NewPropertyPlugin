# Property Plugin - Headless WordPress with React

A WordPress plugin that uses React as a frontend, activated via shortcode.

## Features

- ✅ React frontend rendered via WordPress shortcode
- ✅ WordPress REST API as backend
- ✅ Development mode with hot reload
- ✅ Production build support
- ✅ Responsive card grid layout

## Installation

### 1. Activate the Plugin

1. Go to WordPress Admin → Plugins
2. Find "Property Plugin" and activate it

### 2. Install React Dependencies

Open your terminal and navigate to the plugin directory:

```bash
cd /path/to/wordpress/wp-content/plugins
npm install
```

### 3. Development Mode

To start the React development server with hot reload:

```bash
npm start
```

This will start the development server on `http://localhost:3000`

### 4. Production Build

To build the React app for production:

```bash
npm run build
```

This creates a `build` folder with optimized files.

## Usage

### Add Shortcode to Any Page/Post

Simply add this shortcode to any WordPress page or post:

```
[property_plugin]
```

The React app will automatically render in that location.

### Using in PHP Templates

```php
<?php echo do_shortcode('[property_plugin]'); ?>
```

## How It Works

### WordPress Backend (PHP)

1. **REST API Endpoints**
   - `GET /wp-json/property-plugin/v1/properties` - Get all properties
   - `GET /wp-json/property-plugin/v1/properties/{id}` - Get single property

2. **Shortcode**
   - `[property_plugin]` creates a container div
   - Automatically enqueues React scripts

3. **Data Flow**
   - Fetches WordPress posts via REST API
   - Returns title, content, excerpt, date, and thumbnail

### React Frontend

1. **Components**
   - `App.js` - Main component with property listing
   - Fetches data from WordPress REST API
   - Displays properties in a responsive grid

2. **Development vs Production**
   - **Development**: Loads from `http://localhost:3000`
   - **Production**: Loads from built files in `build/` folder

## Customization

### Modify API Data

Edit `Property_Plugin.php` line 58-77 to change what data is returned:

```php
function property_plugin_get_properties($request) {
    // Change post_type to fetch different content
    $args = array(
        'post_type' => 'post', // Change to your custom post type
        'posts_per_page' => -1,
        'post_status' => 'publish',
    );
    // ...
}
```

### Modify React UI

Edit files in the `src/` folder:
- `src/App.js` - Main component logic
- `src/App.css` - Styles
- `src/index.js` - Entry point

### Add New REST API Endpoints

Add new routes in `Property_Plugin.php`:

```php
register_rest_route('property-plugin/v1', '/custom-endpoint', array(
    'methods' => 'GET',
    'callback' => 'your_callback_function',
    'permission_callback' => '__return_true',
));
```

## File Structure

```
plugins/
├── Property_Plugin.php          # Main WordPress plugin file
├── package.json                 # React dependencies
├── public/
│   └── index.html              # HTML template
├── src/
│   ├── index.js                # React entry point
│   ├── App.js                  # Main React component
│   ├── App.css                 # Component styles
│   └── index.css               # Global styles
└── build/                      # Production build (generated)
    ├── static/js/
    └── static/css/
```

## Troubleshooting

### React app not showing?

1. Check if the shortcode is correctly added: `[property_plugin]`
2. Verify React scripts are enqueued (check page source)
3. Open browser console for errors

### Development mode not working?

1. Make sure `npm start` is running
2. Check that `http://localhost:3000` is accessible
3. Verify no firewall is blocking port 3000

### Production build not loading?

1. Run `npm run build` to create the build folder
2. Check that `build/static/js/main.js` exists
3. Clear WordPress cache if using caching plugin

## API Reference

### Get All Properties

```
GET /wp-json/property-plugin/v1/properties
```

**Response:**
```json
[
  {
    "id": 1,
    "title": "Property Title",
    "content": "Full content...",
    "excerpt": "Short excerpt...",
    "date": "2024-01-01 00:00:00",
    "thumbnail": "https://example.com/image.jpg"
  }
]
```

### Get Single Property

```
GET /wp-json/property-plugin/v1/properties/{id}
```

## Next Steps

- Add custom post types for properties
- Implement filtering and search
- Add pagination
- Create property detail pages
- Add forms for user submissions

## Support

For issues or questions, please check:
- WordPress REST API documentation
- React documentation
- Plugin code comments
