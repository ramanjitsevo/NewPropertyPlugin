import React, { useState, useEffect } from 'react';
import './App.css';
import PropertySingle from './PropertySingle';
import LeadFormModal from './LeadFormModal';

function App({ containerId }) {
  const [properties, setProperties] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [selectedProperty, setSelectedProperty] = useState(null);
  const [showLeadForm, setShowLeadForm] = useState(false);
  const [leadProperty, setLeadProperty] = useState(null);
  
  // Get settings from WordPress
  const settings = window.propertyPluginData?.settings || {};
  
  // Filter states
  const [filters, setFilters] = useState({
    status: 'all',
    keyword: '',
    location: '',
    propertyType: 'all',
    minPrice: '',
    maxPrice: '',
    bedrooms: 'any',
    bathrooms: 'any',
    sortBy: 'latest'
  });
  
  // Pagination states
  const [currentPage, setCurrentPage] = useState(1);
  const postsPerPage = parseInt(settings.propertiesPerPage) || 12;
  
  // Check if user has already submitted the lead form
  const hasSubmittedLeadForm = localStorage.getItem('propertyLeadFormSubmitted') === 'true';

  useEffect(() => {
    console.log('Property Plugin App loaded!');
    console.log('Container ID:', containerId);
    console.log('Property Plugin Data:', window.propertyPluginData);
    fetchProperties();
  }, []);

  const fetchProperties = async () => {
    try {
      setLoading(true);
      const apiUrl = window.propertyPluginData?.apiUrl || '/wp-json/property-plugin/v1';
      
      const response = await fetch(`${apiUrl}/properties`, {
        headers: {
          'X-WP-Nonce': window.propertyPluginData?.nonce || '',
        },
      });

      if (!response.ok) {
        throw new Error('Failed to fetch properties');
      }

      const data = await response.json();
      console.log('Properties fetched:', data);
      console.log('First property structure:', data[0]);
      
      // Log all property types to debug
      const types = data.map(p => ({ id: p.id, title: p.title, type: p.type, property_type: p.property_type, categories: p.categories }));
      console.log('Property types found:', types);
      
      setProperties(data);
      setError(null);
    } catch (err) {
      console.error('Error fetching properties:', err);
      setError(err.message);
    } finally {
      setLoading(false);
    }
  };

  const getStatusBadge = (status) => {
    const statusMap = {
      'for-sale': { label: 'For Sale', color: '#4caf50' },
      'for-rent': { label: 'For Rent', color: '#2196f3' },
      'sold': { label: 'Sold', color: '#f44336' },
      'rented': { label: 'Rented', color: '#ff9800' },
    };
    return statusMap[status] || { label: 'For Sale', color: '#4caf50' };
  };

  const handlePropertyClick = (property) => {
    // If user has already submitted the form, go directly to property page
    if (hasSubmittedLeadForm) {
      setSelectedProperty(property);
      window.scrollTo(0, 0);
    } else {
      // Otherwise show the lead form
      setLeadProperty(property);
      setShowLeadForm(true);
    }
  };

  const handleLeadFormClose = () => {
    setShowLeadForm(false);
    setLeadProperty(null);
  };

  const handleLeadFormSubmit = (formData) => {
    console.log('[App] Lead form submitted successfully for:', formData.email);
    console.log('[App] Property:', leadProperty?.title);
    
    // Save to localStorage that user has submitted the form
    localStorage.setItem('propertyLeadFormSubmitted', 'true');
    
    // Close the modal and open the property page
    setShowLeadForm(false);
    setSelectedProperty(leadProperty);
    setLeadProperty(null);
    window.scrollTo(0, 0);
  };

  const handleBackToList = () => {
    setSelectedProperty(null);
  };

  // Get unique property types from the properties data
  const getUniquePropertyTypes = () => {
    const types = new Set();
    properties.forEach(property => {
      // Check property_type field from WordPress API (primary field)
      let propertyType = property.property_type || property.type || '';
      
      if (propertyType && propertyType !== 'Property') {
        // Capitalize first letter of each word
        const formattedType = propertyType
          .toString()
          .toLowerCase()
          .split(/[\s,]+/) // Split by space or comma
          .map(word => word.trim())
          .filter(word => word.length > 0)
          .map(word => word.charAt(0).toUpperCase() + word.slice(1))
          .join(', ');
        
        if (formattedType) {
          types.add(formattedType);
        }
      }
    });
    console.log('Unique property types found:', Array.from(types));
    return Array.from(types);
  };

  const uniquePropertyTypes = getUniquePropertyTypes();

  // Filter handler functions
  const handleFilterChange = (filterName, value) => {
    setFilters(prev => ({
      ...prev,
      [filterName]: value
    }));
  };

  const handleStatusFilter = (status) => {
    setFilters(prev => ({
      ...prev,
      status: status
    }));
  };

  const handleApplyFilters = () => {
    console.log('Filters applied:', filters);
  };

  const handleResetFilters = () => {
    setFilters({
      status: 'all',
      keyword: '',
      location: '',
      propertyType: 'all',
      minPrice: '',
      maxPrice: '',
      bedrooms: 'any',
      bathrooms: 'any',
      sortBy: 'latest'
    });
    setCurrentPage(1);
  };

  const handleSearch = () => {
    console.log('Search filters:', filters);
  };

  // Parse price string to number
  const parsePrice = (priceString) => {
    if (!priceString) return 0;
    const cleanPrice = priceString.replace(/[^0-9]/g, '');
    return parseFloat(cleanPrice) || 0;
  };

  // Get filtered and sorted properties
  const getFilteredProperties = () => {
    let filtered = [...properties];

    // Filter by status
    if (filters.status !== 'all') {
      filtered = filtered.filter(p => p.status === filters.status);
    }

    // Filter by keyword
    if (filters.keyword) {
      const keyword = filters.keyword.toLowerCase();
      filtered = filtered.filter(p => 
        p.title?.toLowerCase().includes(keyword) ||
        p.description?.toLowerCase().includes(keyword)
      );
    }

    // Filter by location
    if (filters.location) {
      const location = filters.location.toLowerCase();
      filtered = filtered.filter(p => 
        p.address?.toLowerCase().includes(location) ||
        p.location?.toLowerCase().includes(location)
      );
    }

    // Filter by property type
    if (filters.propertyType !== 'all') {
      filtered = filtered.filter(p => {
        // Check property_type field from WordPress API
        const propertyType = (p.property_type || p.type || '').toLowerCase().trim();
        const filterType = filters.propertyType.toLowerCase().trim();
        
        // Remove trailing 's' for plural matching
        const singularPropertyType = propertyType.replace(/s$/, '');
        const singularFilterType = filterType.replace(/s$/, '');
        
        // Exact match, contains match, or singular/plural match
        return propertyType === filterType || 
               singularPropertyType === singularFilterType ||
               propertyType.includes(filterType) ||
               filterType.includes(propertyType);
      });
    }

    // Filter by price range
    if (filters.minPrice) {
      const minPrice = parseFloat(filters.minPrice);
      filtered = filtered.filter(p => parsePrice(p.price) >= minPrice);
    }

    if (filters.maxPrice) {
      const maxPrice = parseFloat(filters.maxPrice);
      filtered = filtered.filter(p => parsePrice(p.price) <= maxPrice);
    }

    // Filter by bedrooms
    if (filters.bedrooms !== 'any') {
      const bedrooms = parseInt(filters.bedrooms);
      if (filters.bedrooms === '5+') {
        filtered = filtered.filter(p => parseInt(p.bedrooms) >= 5);
      } else {
        filtered = filtered.filter(p => parseInt(p.bedrooms) === bedrooms);
      }
    }

    // Filter by bathrooms
    if (filters.bathrooms !== 'any') {
      const bathrooms = parseInt(filters.bathrooms);
      if (filters.bathrooms === '5+') {
        filtered = filtered.filter(p => parseInt(p.bathrooms) >= 5);
      } else {
        filtered = filtered.filter(p => parseInt(p.bathrooms) === bathrooms);
      }
    }

    // Sort properties
    if (filters.sortBy === 'price-low') {
      filtered.sort((a, b) => parsePrice(a.price) - parsePrice(b.price));
    } else if (filters.sortBy === 'price-high') {
      filtered.sort((a, b) => parsePrice(b.price) - parsePrice(a.price));
    }

    return filtered;
  };

  const filteredProperties = getFilteredProperties();
  
  // Pagination logic
  const totalPages = Math.ceil(filteredProperties.length / postsPerPage);
  const indexOfLastPost = currentPage * postsPerPage;
  const indexOfFirstPost = indexOfLastPost - postsPerPage;
  const currentPosts = filteredProperties.slice(indexOfFirstPost, indexOfLastPost);
  
  // Reset to page 1 when filters change
  useEffect(() => {
    setCurrentPage(1);
  }, [filters]);
  
  const handlePageChange = (pageNumber) => {
    setCurrentPage(pageNumber);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  if (loading) {
    return <div className="property-plugin-loading">Loading properties...</div>;
  }

  if (error) {
    return <div className="property-plugin-error">Error: {error}</div>;
  }

  // Show single property page if a property is selected
  if (selectedProperty) {
    return <PropertySingle property={selectedProperty} onBack={handleBackToList} settings={settings} />;
  }

  return (
    <div className="property-plugin-app" id={containerId}>
      {/* Apply custom CSS from settings */}
      {settings.customCSS && (
        <style dangerouslySetInnerHTML={{ __html: settings.customCSS }} />
      )}
      
      {/* Apply global styles from settings */}
      <style>{`
        .property-plugin-app {
          font-family: ${settings.fontFamily || 'Arial, sans-serif'};
          font-size: ${settings.fontSize || '16'}px;
          color: ${settings.textColor || '#1f2937'};
          background-color: ${settings.backgroundColor || '#f3f4f6'};
        }
      `}</style>

      {/* Lead Form Modal */}
      {showLeadForm && leadProperty && (
        <LeadFormModal 
          property={leadProperty} 
          onClose={handleLeadFormClose}
          onSubmit={handleLeadFormSubmit}
        />
      )}

      {/* Hero Section */}
      <section 
        className="hero-section"
        style={{
          backgroundImage: settings.bannerImage ? `url(${settings.bannerImage})` : 'linear-gradient(135deg, #667eea 0%, #764ba2 100%)',
          backgroundSize: 'cover',
          backgroundPosition: 'center',
          height: `${settings.bannerHeight || 400}px`,
          position: 'relative'
        }}
      >
        <div 
          className="hero-overlay"
          style={{
            backgroundColor: settings.bannerOverlayColor || '#000000',
            opacity: (settings.bannerOverlay || 50) / 100
          }}
        ></div>
        <div className="hero-content">
          <h1 className="hero-title">{settings.headerText || 'Discover Your Perfect Property'}</h1>
          {settings.bannerSubtitle && <p className="hero-subtitle">{settings.bannerSubtitle}</p>}
        </div>
      </section>

      {/* Search Bar Section */}
      <section className="search-section">
        <div className="search-container">
          <div className="search-tabs">
            <button 
              className={`search-tab ${filters.status === 'all' ? 'active' : ''}`}
              onClick={() => handleStatusFilter('all')}
            >
              All Status
            </button>
            <button 
              className={`search-tab ${filters.status === 'for-sale' ? 'active' : ''}`}
              onClick={() => handleStatusFilter('for-sale')}
            >
              For Sale
            </button>
            <button 
              className={`search-tab ${filters.status === 'for-rent' ? 'active' : ''}`}
              onClick={() => handleStatusFilter('for-rent')}
            >
              For Rent
            </button>
            <button 
              className={`search-tab ${filters.status === 'new-launch' ? 'active' : ''}`}
              onClick={() => handleStatusFilter('new-launch')}
            >
              New Launch
            </button>
          </div>
          <div className="search-form">
            <div className="search-field">
              <label>Keyword</label>
              <input 
                type="text" 
                placeholder="Enter keyword..." 
                value={filters.keyword}
                onChange={(e) => handleFilterChange('keyword', e.target.value)}
              />
            </div>
            <div className="search-field">
              <label>Location</label>
              <input 
                type="text" 
                placeholder="Enter location..." 
                value={filters.location}
                onChange={(e) => handleFilterChange('location', e.target.value)}
              />
            </div>
            <div className="search-field">
              <label>Property Type</label>
              <select 
                value={filters.propertyType}
                onChange={(e) => handleFilterChange('propertyType', e.target.value)}
              >
                <option value="all">All Types</option>
                {uniquePropertyTypes.map(type => (
                  <option key={type} value={type.toLowerCase()}>
                    {type}
                  </option>
                ))}
              </select>
            </div>
            <div className="search-field">
              <label>Min Price</label>
              <input 
                type="number" 
                placeholder="Min Price" 
                value={filters.minPrice}
                onChange={(e) => handleFilterChange('minPrice', e.target.value)}
              />
            </div>
            <div className="search-field">
              <label>Max Price</label>
              <input 
                type="number" 
                placeholder="Max Price" 
                value={filters.maxPrice}
                onChange={(e) => handleFilterChange('maxPrice', e.target.value)}
              />
            </div>
            <button className="btn-search" onClick={handleSearch}>Search Properties</button>
          </div>
          <div className="search-advanced">
            <button className="btn-advanced">Advanced ▼</button>
          </div>
        </div>
      </section>

      {/* Properties Listing Section */}
      <section className="properties-section">
        <div className="properties-container">
          <div className="properties-layout">
            {/* Sidebar Filters */}
            {settings.enableFilters !== '0' && (
              <aside 
                className="properties-sidebar"
                style={{
                  order: settings.sidebarPosition === 'right' ? '2' : '1',
                  width: `${settings.sidebarWidth || 280}px`
                }}
              >
              <div className="filter-header">
                <h3>Filter Properties</h3>
                <button className="btn-reset" onClick={handleResetFilters}>Reset</button>
              </div>

              <div className="filter-group">
                <h4>Location</h4>
                <input 
                  type="text" 
                  placeholder="Enter location..." 
                  value={filters.location}
                  onChange={(e) => handleFilterChange('location', e.target.value)}
                />
              </div>

              <div className="filter-group">
                <h4>Property Type</h4>
                <div className="filter-options">
                  <label>
                    <input 
                      type="radio" 
                      name="propertyType"
                      checked={filters.propertyType === 'all'}
                      onChange={() => handleFilterChange('propertyType', 'all')}
                    /> All Types
                  </label>
                  {uniquePropertyTypes.map(type => (
                    <label key={type}>
                      <input 
                        type="radio" 
                        name="propertyType"
                        checked={filters.propertyType === type.toLowerCase()}
                        onChange={() => handleFilterChange('propertyType', type.toLowerCase())}
                      /> {type}
                    </label>
                  ))}
                </div>
              </div>

              <div className="filter-group">
                <h4>Price Range</h4>
                <div className="price-range-inputs">
                  <input 
                    type="number" 
                    placeholder="Min Price" 
                    value={filters.minPrice}
                    onChange={(e) => handleFilterChange('minPrice', e.target.value)}
                    style={{ width: '48%', padding: '8px', marginBottom: '10px' }}
                  />
                  <input 
                    type="number" 
                    placeholder="Max Price" 
                    value={filters.maxPrice}
                    onChange={(e) => handleFilterChange('maxPrice', e.target.value)}
                    style={{ width: '48%', padding: '8px', marginBottom: '10px' }}
                  />
                </div>
                <div className="price-range">
                  <span>$10,000</span>
                  <input 
                    type="range" 
                    className="price-slider" 
                    min="10000" 
                    max="5000000" 
                    step="10000" 
                    value={filters.maxPrice || 2500000}
                    onChange={(e) => handleFilterChange('maxPrice', e.target.value)}
                  />
                  <span>$5,000,000</span>
                </div>
              </div>

              <div className="filter-group">
                <h4>Bedrooms</h4>
                <div className="number-options">
                  <button 
                    className={`number-btn ${filters.bedrooms === 'any' ? 'active' : ''}`}
                    onClick={() => handleFilterChange('bedrooms', 'any')}
                  >
                    Any
                  </button>
                  {[1, 2, 3, 4, '5+'].map(num => (
                    <button 
                      key={num} 
                      className={`number-btn ${filters.bedrooms === num.toString() ? 'active' : ''}`}
                      onClick={() => handleFilterChange('bedrooms', num.toString())}
                    >
                      {num}
                    </button>
                  ))}
                </div>
              </div>

              <div className="filter-group">
                <h4>Bathrooms</h4>
                <div className="number-options">
                  <button 
                    className={`number-btn ${filters.bathrooms === 'any' ? 'active' : ''}`}
                    onClick={() => handleFilterChange('bathrooms', 'any')}
                  >
                    Any
                  </button>
                  {[1, 2, 3, 4, '5+'].map(num => (
                    <button 
                      key={num} 
                      className={`number-btn ${filters.bathrooms === num.toString() ? 'active' : ''}`}
                      onClick={() => handleFilterChange('bathrooms', num.toString())}
                    >
                      {num}
                    </button>
                  ))}
                </div>
              </div>

              <button className="btn-apply-filters" onClick={handleApplyFilters}>Apply Filters</button>
            </aside>
            )}

            {/* Main Content */}
            <div 
              className="properties-main"
              style={{
                order: settings.sidebarPosition === 'right' ? '1' : '2',
                flex: settings.enableFilters !== '0' ? '1' : 'none',
                width: settings.enableFilters === '0' ? '100%' : 'auto'
              }}
            >
              <div className="properties-header">
                <div>
                  <p className="results-count">Showing {indexOfFirstPost + 1}-{Math.min(indexOfLastPost, filteredProperties.length)} of {filteredProperties.length} Properties</p>
                  <p style={{ fontSize: '12px', color: '#999', marginTop: '5px' }}>
                    Available Types: {uniquePropertyTypes.length > 0 ? uniquePropertyTypes.join(', ') : 'None found'}
                  </p>
                </div>
                <div className="sort-options">
                  <label>Sort By:</label>
                  <select 
                    value={filters.sortBy}
                    onChange={(e) => handleFilterChange('sortBy', e.target.value)}
                  >
                    <option value="latest">Latest</option>
                    <option value="price-low">Price: Low to High</option>
                    <option value="price-high">Price: High to Low</option>
                  </select>
                  {/* <div className="view-toggle">
                    <button className="view-btn active"></button>
                    <button className="view-btn">⊞</button>
                  </div> */}
                </div>
              </div>

              {/* Properties Grid */}
              <div className={`properties-grid ${settings.cardLayout === 'list' ? 'list-layout' : ''}`}>
                {currentPosts.length === 0 ? (
                  <div className="no-properties">
                    <p>No properties found matching your filters. Try adjusting your search criteria.</p>
                    <button className="btn-add-first" onClick={handleResetFilters}>
                      Reset Filters
                    </button>
                  </div>
                ) : (
                  currentPosts.map((property) => {
                    const statusInfo = getStatusBadge(property.status);
                    return (
                      <div 
                        key={property.id} 
                        className="property-card"
                        style={{
                          cursor: 'pointer',
                          backgroundColor: settings.cardBackground || '#ffffff'
                        }}
                        onClick={() => handlePropertyClick(property)}
                      >
                        <div className="property-image-container">
                          {property.thumbnail ? (
                            <img 
                              src={property.thumbnail} 
                              alt={property.title}
                              className="property-image"
                            />
                          ) : (
                            <div className="property-image-placeholder">
                              <span>No Image</span>
                            </div>
                          )}
                          {settings.showBadge !== '0' && (
                            <div 
                              className="property-badge"
                              style={{ backgroundColor: statusInfo.color }}
                            >
                              {statusInfo.label}
                            </div>
                          )}
                          {/* <button 
                            className="btn-favorite"
                            onClick={(e) => e.stopPropagation()}
                          >
                            ♡
                          </button> */}
                        </div>
                        <div className="property-details">
                          <h3 className="property-name">{property.title}</h3>
                          {settings.showAddress !== '0' && (
                            <p className="property-address">📍 {property.city || property.address}</p>
                          )}
                          <p className="property-price" style={{ color: settings.primaryColor || '#2563eb' }}>{property.price}</p>
                          <div className="property-features">
                            {property.bedrooms && property.bedrooms !== 'N/A' && (
                              <span> {property.bedrooms} Beds</span>
                            )}
                            {property.bathrooms && property.bathrooms !== 'N/A' && (
                              <span><i className="fas fa-bath"></i> {property.bathrooms} Baths</span>
                            )}
                            {property.floor && property.floor !== 'N/A' && (
                              <span><i className="fas fa-building"></i> Floor: {property.floor}</span>
                            )}
                            {settings.showArea !== '0' && property.area && property.area !== 'N/A' && (
                              <span><i className="fas fa-ruler-combined"></i> {property.area}</span>
                            )}
                          </div>
                        </div>
                      </div>
                    );
                  })
                )}
              </div>
                  {/* Pagination */}
              {totalPages > 1 && (
                <div className="pagination">
                  <button 
                    className="page-btn" 
                    onClick={() => handlePageChange(currentPage - 1)}
                    disabled={currentPage === 1}
                    style={{ opacity: currentPage === 1 ? 0.5 : 1, cursor: currentPage === 1 ? 'not-allowed' : 'pointer' }}
                  >
                    ‹
                  </button>
                  {Array.from({ length: totalPages }, (_, index) => index + 1).map(pageNum => (
                    <button 
                      key={pageNum}
                      className={`page-btn ${currentPage === pageNum ? 'active' : ''}`}
                      onClick={() => handlePageChange(pageNum)}
                    >
                      {pageNum}
                    </button>
                  ))}
                  <button 
                    className="page-btn" 
                    onClick={() => handlePageChange(currentPage + 1)}
                    disabled={currentPage === totalPages}
                    style={{ opacity: currentPage === totalPages ? 0.5 : 1, cursor: currentPage === totalPages ? 'not-allowed' : 'pointer' }}
                  >
                    ›
                  </button>
                </div>
              )}
            </div>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="cta-section">
        <div className="cta-container">
          <div className="cta-image">
            <img src="https://images.unsplash.com/photo-1564013799919-ab600027ffc6?w=500" alt="Property" />
          </div>
          <div className="cta-content">
            <h2>Want to Sell or Rent Your Property?</h2>
            <p>List your property with us and reach thousands of potential buyers and renters.</p>
            <a href="/wp-admin/post-new.php?post_type=property" className="btn-add-property-large">
              Add Property Now
            </a>
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section className="features-section">
        <div className="features-container">
          <div className="feature-item">
            <div className="feature-icon"><i className="fas fa-trophy"></i></div>
            <h4>Trusted by Thousands</h4>
            <p>Join thousands of happy clients who found their perfect property.</p>
          </div>
          <div className="feature-item">
            <div className="feature-icon"><i className="fas fa-chart-bar"></i></div>
            <h4>Wide Range of Properties</h4>
            <p>Explore a wide range of properties for sale and rent.</p>
          </div>
          <div className="feature-item">
            <div className="feature-icon"><i className="fas fa-users"></i></div>
            <h4>Expert Agents</h4>
            <p>Work with experienced agents to find the best property.</p>
          </div>
          <div className="feature-item">
            <div className="feature-icon"><i className="fas fa-shield-alt"></i></div>
            <h4>Secure & Easy Process</h4>
            <p>Enjoy a secure and hassle-free property buying or renting process.</p>
          </div>
        </div>
      </section>
    </div>
  );
}

export default App;
